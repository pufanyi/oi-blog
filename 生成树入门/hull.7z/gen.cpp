#include <ctime>
#include <fstream>
#include <algorithm>

using namespace std;

int main() {
    int n = 1000000;
    mt19937 rnd(time(0));
    ofstream fout("hull.in");
    fout << n << '\n';
    for (int i = 1; i <= n; ++i) {
        fout << rnd() % 1000000000 - 500000000 << ' ' << rnd() % 1000000000 - 500000000 << '\n';
    }
    fout.close();
    return 0;
}
