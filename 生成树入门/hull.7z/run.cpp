#include <cstdlib>
#include <fstream>
#include <iostream>

using namespace std;

int main() {
    long long ans = 0;
    int cnt = 0;
    while (true) {
        system("gen");
        system("hull");
        ifstream fin("hull.out");
        int anss;
        fin >> anss;
        ans += anss;
        fin.close();
        system("cls");
        cout << (double) ans / (++cnt) << endl;
    }
    return 0;
}
