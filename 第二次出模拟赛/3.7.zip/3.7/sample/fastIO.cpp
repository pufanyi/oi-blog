/**
 * һ����������Ż����� 
 * �������һ��Ҫ���ļ�������
 * ϣ����AK�������� 
**/ 

#include <cctype>
#include <cstdio>

inline char gc()
{
	static const int L = 233333;
	static char sxd[L], *sss = sxd, *ttt = sxd;
	if(sss == ttt)
	{
		ttt = (sss = sxd) + fread(sxd, 1, L, stdin);
		if(sss == ttt)
			return EOF;
	}
	return *sss++;
}

#define dd c = gc()
template<class T>
inline bool read(T& x)
{
	x = 0;
	char dd;
	bool f = false;
	for(; !isdigit(c); dd)
	{
		if(c == '-')
			f = true;
		else if(c == EOF)
			return false;
	}
	for(; isdigit(c); dd)
		x = (x << 1) + (x << 3) + (c ^ 48);
	if(f)
		x = -x;
	return true;
}
#undef dd

template <class T>
inline void writesp(T x) // ���֮����һ���ո� 
{
    if(!x)
    {
        putchar('0');
        putchar(' ');
        return;
    }
    if(x < 0)
    {
        putchar('-');
        x = -x;
    }
    int bit[20] = {0};
    while(x)
    {
        bit[++(*bit)] = (x % 10) | 48;
        x /= 10;
    }
    do
        putchar(bit[*bit]);
    while(--(*bit));
    putchar(' ');
}

int main()
{
	freopen("fastIO.in", "r", stdin);
	int a;
	read(a);
	writesp(a);
	long long b;
	while(read(b))
	{
		writesp(b);
		puts("");
	}
	fclose(stdin);
	return 0;
}
