#include <cctype>
#include <cstdio>
#include <algorithm>

using namespace std;

typedef long long LL;

inline char gc()
{
	static const int L = 233333;
	static char sxd[L], *sss = sxd, *ttt = sxd;
	if(sss == ttt)
	{
		ttt = (sss = sxd) + fread(sxd, 1, L, stdin);
		if(sss == ttt)
			return EOF;
	}
	return *sss++;
}

#define dd c = gc()
template<class T>
inline bool read(T& x)
{
	x = 0;
	char dd;
	bool f = false;
	for(; !isdigit(c); dd)
	{
		if(c == '-')
			f = true;
		else if(c == EOF)
			return false;
	}
	for(; isdigit(c); dd)
		x = (x << 1) + (x << 3) + (c ^ 48);
	if(f)
		x = -x;
	return true;
}
#undef dd

const int mod = 998244353;
const int maxn = 1005;

int f[maxn][maxn];
int a[maxn];
int n, k;

int main()
{
	freopen("l.in", "r", stdin);
	freopen("l.out", "w", stdout);
	read(n);
	for(int i = 1; i <= n; ++i)
		read(a[i]);
	for(int i = 1; i <= n; ++i)
	{
		while(i != a[i])
		{
			swap(a[i], a[a[i]]);
			k++;
		}
	}
	for(int i = 1; i <= n; ++i)
	{
		f[i][0] = 1;
		for(int j = 1; j <= k; ++j)
			f[i][j] = (f[i - 1][j] + (LL) f[i - 1][j - 1] * (i - 1) % mod) % mod;
	}
	printf("1 %d\n", k);
	printf("2 %d\n", f[n][k]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
