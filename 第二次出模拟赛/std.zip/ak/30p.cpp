#include <cstdio>
#include <iostream>
#include <algorithm>

using namespace std;

const int maxn = 100005;

inline char gc()
{
	static const int L = 233333;
	static char sxd[L], *sss = sxd, *ttt = sxd;
	if(sss == ttt)
	{
		ttt = (sss = sxd) + fread(sxd, 1, L, stdin);
		if(sss == ttt)
			return EOF;
	}
	return *sss++;
}

#define dd c = gc()
template<class T>
inline bool read(T& x)
{
	x = 0;
	char dd;
	bool f = false;
	for(; !isdigit(c); dd)
	{
		if(c == '-')
			f = true;
		else if(c == EOF)
			return false;
	}
	for(; isdigit(c); dd)
		x = (x << 1) + (x << 3) + (c ^ 48);
	if(f)
		x = -x;
	return true;
}
#undef dd

template <class T>
inline void writesp(T x) // 输出之后会加一个空格
{
    if(!x)
    {
        putchar('0');
        putchar(' ');
        return;
    }
    if(x < 0)
    {
        putchar('-');
        x = -x;
    }
    int bit[20] = {0};
    while(x)
    {
        bit[++(*bit)] = (x % 10) | 48;
        x /= 10;
    }
    do
        putchar(bit[*bit]);
    while(--(*bit));
    putchar(' ');
}

inline int gcd(int a, int b)
{
	int t;
	while(b)
	{
		t = a % b;
		a = b;
		b = t;
	}
	return a;
}

int a[maxn];
int n, m;

int main()
{
	freopen("ak.in", "r", stdin);
	freopen("ak.out", "w", stdout);
	read(n), read(m);
	for(int i = 1; i <= n; ++i)
		read(a[i]);
    int opt, l, r, x;
    while(m--)
    {
        read(opt);
		if(opt == 1)
		{
			read(l), read(r), read(x);
            for(int i = l; i <= r; ++i)
                a[i] += x;
		}
		else
		{
			read(l), read(r);
            int ans = 0;
            for(int i = l; i <= r; ++i)
            {
                ans = gcd(a[i], ans);
                if(ans == 1 || ans == -1)
                    break;
            }
			writesp(ans);
			puts("");
		}
    }
	fclose(stdin);
	fclose(stdout);
	return 0;
}
