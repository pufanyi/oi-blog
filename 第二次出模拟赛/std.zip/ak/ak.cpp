#include <cstdio>
#include <iostream>
#include <algorithm>

using namespace std;

const int maxn = 100005;

inline char gc()
{
	static const int L = 233333;
	static char sxd[L], *sss = sxd, *ttt = sxd;
	if(sss == ttt)
	{
		ttt = (sss = sxd) + fread(sxd, 1, L, stdin);
		if(sss == ttt)
			return EOF;
	}
	return *sss++;
}

#define dd c = gc()
template<class T>
inline bool read(T& x)
{
	x = 0;
	char dd;
	bool f = false;
	for(; !isdigit(c); dd)
	{
		if(c == '-')
			f = true;
		else if(c == EOF)
			return false;
	}
	for(; isdigit(c); dd)
		x = (x << 1) + (x << 3) + (c ^ 48);
	if(f)
		x = -x;
	return true;
}
#undef dd

template <class T>
inline void writesp(T x)
{
    if(!x)
    {
        putchar('0');
        putchar(' ');
        return;
    }
    if(x < 0)
    {
        putchar('-');
        x = -x;
    }
    int bit[20] = {0};
    while(x)
    {
        bit[++(*bit)] = (x % 10) | 48;
        x /= 10;
    }
    do
        putchar(bit[*bit]);
    while(--(*bit));
    putchar(' ');
}

inline int gcd(int a, int b)
{
	int t;
	while(b)
	{
		t = a % b;
		a = b;
		b = t;
	}
	return a;
}

int a[maxn];
int n, m;

#define ls(x) (x << 1)
#define rs(x) (x << 1 | 1)
#define lowbit(x) (x & (-x))

struct add_tree
{
	int no[maxn];

	inline void add(int pla, int x)
	{
		for(; pla <= n; pla += lowbit(pla))
			no[pla] += x;
	}

	inline void add(int l, int r, int x)
	{
		add(l, x);
		if(r < n)
			add(r + 1, -x);
	}

	inline int query(int pla)
	{
		int ans = 0;
		for(; pla; pla -= lowbit(pla))
			ans += no[pla];
		return ans;
	}
} sl;

struct gcd_Tree
{
	int no[maxn << 2];
	int k;

	inline void build_tree()
	{
		for(k = 1; k <= n; k <<= 1);
		for(int i = 1; i <= n; ++i)
			no[i + k] = a[i] - a[i - 1];
		for(int i = k; i; --i)
			no[i] = gcd(no[ls(i)], no[rs(i)]);
	}

	inline void add(int pla, int x)
	{
		for(pla += k, no[pla] += x, pla >>= 1; pla; pla >>= 1)
			no[pla] = gcd(no[ls(pla)], no[rs(pla)]);
	}

	inline void add(int l, int r, int x)
	{
		add(l, x);
		if(r < n)
			add(r + 1, -x);
	}

	inline int query(int l, int r)
	{
		int ans = 0;
		for(l += k - 1, r += k + 1; l ^ r ^ 1; l >>= 1, r >>= 1)
		{
			if(~l & 1)
				ans = gcd(ans, no[l ^ 1]);
			if(r & 1)
				ans = gcd(ans, no[r ^ 1]);
		}
		return ans;
	}
} tr;

int main()
{
	freopen("ak.in", "r", stdin);
	freopen("ak.out", "w", stdout);
	read(n), read(m);
	for(int i = 1; i <= n; ++i)
		read(a[i]);
	tr.build_tree();
	for(int i = 1; i <= n; ++i)
		sl.add(i, a[i] - a[i - 1]);
	int opt, l, r, x;
	while(m--)
	{
		read(opt);
		if(opt == 1)
		{
			read(l), read(r), read(x);
			tr.add(l, r, x);
			sl.add(l, r, x);
		}
		else
		{
			read(l), read(r);
			writesp(abs(gcd(tr.query(l + 1, r), sl.query(l))));
			puts("");
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
