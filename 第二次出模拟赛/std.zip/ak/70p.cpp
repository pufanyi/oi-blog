#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
inline char gc(){
	static char buf[1<<14],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<14,stdin),p1==p2)?EOF:*p1++;
}
template<class T>inline int read(T&x){
	x=0;bool f=1;char c=gc();
	for(;!isdigit(c);c=gc()){if(c=='-')f^=1;if(c==-1)return-1;}
	for(;isdigit(c);c=gc())x=(x<<1)+(x<<3)+(c^48);x=f?x:-x;
	return 1;
}
#define pc putchar
template<class T>inline void wr(T x){
	if(x<0)pc('-'),x=-x;
	if(x>9)wr(x/10);pc(x%10|48);
}
inline void file(){
	freopen("ak.in","r",stdin);
	freopen("ak.out","w",stdout);
}
const int N=1e5+10;
int n,m,a[20][N],lg[N];
inline int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
inline int query(int l,int r){
	int k=lg[r-l+1];
	return gcd(a[k][l],a[k][r-(1<<k)+1]);
}
int main(){
	file();
	read(n),read(m);
	for (int i=1;i<=n;++i) read(a[0][i]);
	for (int i=1;i<=20;++i)
		for (int j=1;j+(1<<i)-1<=n;++j)
			a[i][j]=gcd(a[i-1][j],a[i-1][j+(1<<i-1)]);
	for (int i=2;i<=n;++i) lg[i]=lg[i>>1]+1;
	for (int i=1,l,r,cmd;i<=m;++i){
		read(cmd),read(l),read(r);
		wr(query(l,r));
		puts("");
	}
	return 0;
}
