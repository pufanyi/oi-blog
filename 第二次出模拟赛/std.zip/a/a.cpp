#include <cstdio>
#include <cctype>
#include <cstring>
#include <iostream>

using namespace std;

inline char gc()
{
	static const int L = 233333;
	static char sxd[L], *sss = sxd, *ttt = sxd;
	if(sss == ttt)
	{
		ttt = (sss = sxd) + fread(sxd, 1, L, stdin);
		if(sss == ttt)
			return EOF;
	}
	return *sss++;
}

#define dd c = gc()
template<class T>
inline bool read(T& x)
{
	x = 0;
	char dd;
	bool f = false;
	for(; !isdigit(c); dd)
	{
		if(c == '-')
			f = true;
		else if(c == EOF)
			return false;
	}
	for(; isdigit(c); dd)
		x = (x << 1) + (x << 3) + (c ^ 48);
	if(f)
		x = -x;
	return true;
}
#undef dd

template <class T>
inline void writesp(T x)
{
    if(!x)
    {
        putchar('0');
        putchar(' ');
        return;
    }
    if(x < 0)
    {
        putchar('-');
        x = -x;
    }
    int bit[20] = {0};
    while(x)
    {
        bit[++(*bit)] = (x % 10) | 48;
        x /= 10;
    }
    do
        putchar(bit[*bit]);
    while(--(*bit));
    putchar(' ');
}

const int maxn = 5005;
const int inf = 0x3f3f3f3f;

int n, m, s;

int d[maxn][maxn];
int dist[maxn];
bool vis[maxn];

inline void dijkstra()
{
	memset(dist, 0x3f, sizeof(dist));
	dist[1] = 0;
	for(register int i = 1, j; i <= n; ++i)
	{
		register int now = 0;
		for(int j = 1; j <= n; ++j)
			if(!vis[j] && (!now || dist[j] < dist[now]))
				now = j;
		if(!now)
			break;
		vis[now] = true;
		for(int j = 1; j <= n; ++j)
			if(!vis[j] && dist[j] > dist[now] + d[now][j])
				dist[j] = dist[now] + d[now][j];
	}
}

int main()
{
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
	read(n), read(m);
	int f, t, di;
	memset(d, 0x3f, sizeof(d));
	for(register int i = 1; i <= m; ++i)
	{
		read(f), read(t), read(di);
		d[f][t] = d[t][f] = di;
	}
	dijkstra();
	for(register int i = 2; i <= n; ++i)
		writesp(dist[i]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
