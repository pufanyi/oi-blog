// luogu-judger-enable-o2
#include <cstdio>
#include <cctype>
#include <cstring>
#include <iostream>

using namespace std;

#include <cctype>
#include <cstdio>

inline char gc()
{
	static const int L = 233333;
	static char sxd[L], *sss = sxd, *ttt = sxd;
	if(sss == ttt)
	{
		ttt = (sss = sxd) + fread(sxd, 1, L, stdin);
		if(sss == ttt)
			return EOF;
	}
	return *sss++;
}

#define dd c = gc()
template<class T>
inline bool read(T& x)
{
	x = 0;
	char dd;
	bool f = false;
	for(; !isdigit(c); dd)
	{
		if(c == '-')
			f = true;
		else if(c == EOF)
			return false;
	}
	for(; isdigit(c); dd)
		x = (x << 1) + (x << 3) + (c ^ 48);
	if(f)
		x = -x;
	return true;
}
#undef dd

template <class T>
inline void writesp(T& x) // ���֮����һ���ո� 
{
    if(!x)
    {
        putchar('0');
        putchar(' ');
        return;
    }
    if(x < 0)
    {
        putchar('-');
        x = -x;
    }
    int bit[20] = {0};
    while(x)
    {
        bit[++(*bit)] = (x % 10) | 48;
        x /= 10;
    }
    do
        putchar(bit[*bit]);
    while(--(*bit));
    putchar(' ');
}

const int maxn = 5005;
const int maxm = maxn * maxn;
const int inf = 0x3f3f3f3f;

int n, m;

struct Edge
{
    int to, dist, nxt;
} e[maxm << 1];

int first[maxn];

inline void add_edge(int from, int to, int dist)
{
    static int cnt = 0;
//	cout << from << ' ' << to << endl;
    e[++cnt].nxt = first[from];
    first[from] = cnt;
    e[cnt].dist = dist;
    e[cnt].to = to;
    e[++cnt].nxt = first[to];
    first[to] = cnt;
    e[cnt].dist = dist;
    e[cnt].to = from;
}

int dist[maxn];

struct DIJKSTRA
{
#define ls(x) (x << 1)
#define rs(x) (x << 1 | 1)
    struct Tree
    {
        int no[maxn << 2];
        int t;

        inline void build_tree()
        {
            for(t = 1; t <= n; t <<= 1);
            for(register int i = 1; i <= n; ++i)
                no[i + t] = i;
        }

        inline void change(int k)
        {
            for(k += t, k >>= 1; k; k >>= 1)
                no[k] = dist[no[ls(k)]] < dist[no[rs(k)]]
                        ? no[ls(k)] : no[rs(k)];
        }

        inline void del(int k)
        {
            for(no[k += t] = 0, k >>= 1; k; k >>= 1)
                no[k] = dist[no[ls(k)]] < dist[no[rs(k)]]
                        ? no[ls(k)] : no[rs(k)];
        }
    } tr;

    inline void dijkstra()
    {
        memset(dist, 0x3f, sizeof(dist));
        dist[1] = 0;
        tr.build_tree();
        tr.change(1);
        for(register int i = 1; i <= n; ++i)
        {
            register int now = tr.no[1];
            if(!now || dist[now] >= inf)
                break;
//			cout << "now = " << now << endl;
            tr.del(now);
            for(register int j = first[now]; j; j = e[j].nxt)
            {
                register int to = e[j].to;
//				cout << "to = " << to << endl;
                if(dist[to] > dist[now] + e[j].dist)
                {
                    dist[to] = dist[now] + e[j].dist;
                    tr.change(to);
                }
            }
        }
    }
} dij;

int main()
{
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
    read(n), read(m);
//	printf("%d %d %d\n", n, m, s);
    int f, t, d;
    for(register int i = 1; i <= m; ++i)
    {
        read(f), read(t), read(d);
        add_edge(f, t, d);
    }
    dij.dijkstra();
    for(register int i = 2; i <= n; ++i)
        writesp(dist[i]);
	fclose(stdin);
	fclose(stdout);
    return 0;
}
