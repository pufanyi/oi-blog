#include <fstream>
#include <iostream>

using namespace std;

typedef long long LL;

const int mod = 998244353;

inline int pow(int a, LL b)
{
	int ans = 1;
	for(; b; b >>= 1, a = (LL) a * a % mod)
		if(b & 1)
			ans = (LL) ans * a % mod;
	return ans;
}

int main()
{
	ifstream fin("b.in");
	ofstream fout("b.out");
	LL n;
	fin >> n;
	if(n == 1)
	{
		fout << 1;
		fin.close();
		fout.close();
		return 0;
	}
	LL tmp = n / 3;
	int tmpp = n % 3;
	if(tmpp == 1)
	{
		tmpp = 4;
		tmp--;
	}
	else if(!tmpp)
		tmpp = 1;
	fout << (LL) pow(3, tmp) * tmpp % mod;
	fin.close();
	fout.close();
	return 0;
}

